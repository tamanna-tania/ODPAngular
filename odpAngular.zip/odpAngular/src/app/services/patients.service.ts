import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PatientsService {
baseUrl='http://localhost:5172/api'
  constructor(private http:HttpClient) { }
  //GetAllPatients
  // saveData(){
  //   return this.http.post(this.baseUrl + '/PostAsync',);
  // }
  getData(){
    return this.http.get(this.baseUrl + '/GetAsync');
  }
}
