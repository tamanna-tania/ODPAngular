export interface Patients {
  patientId:number;
  patientName:string;
  address:string;
  phone:string
}
